# 自定义属性
## :listType 用来控制列表是
  - 横向 (true)
  - 纵向 (false)
## :listdata 用来传递
  - 列表数组 (数组)
## :isCheckd 用来控制列表项能否被选中
  - 能 (true)
  - 不能 (false)
## :getCheckData 返回选中的数据
  - 传递类型(function)

# 插槽
## slot="XrightDown"
  - 向横向列表右下角添加标签
## slot="XrightTop"
  - 向横向列表右上角添加标签
## slot="YrightDown"
  - 向纵向列表右下角添加标签

